package com.dextzy.shop

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val status = TextView(this)
        status.text = "DexTzy Shop Ready"

        val btn = Button(this)
        btn.text = "BOT READY"

        layout.addView(status)
        layout.addView(btn)

        setContentView(layout)
    }
}
